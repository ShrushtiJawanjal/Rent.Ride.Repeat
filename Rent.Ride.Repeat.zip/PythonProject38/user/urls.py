from django.urls import path
from .import views

urlpatterns=[
    path('home', views.home, name='home'),
    path('signup', views.signup, name='signup'),
    path('',views.login,name='login'),
    path('gallery',views.gallery,name='gallery'),
    path('books',views.books,name='books'),
    path('complaints',views.complaints,name='complaints'),
    path('login',views.login,name='login'),
    path('status/<int:id>/', views.status, name='status'),

]