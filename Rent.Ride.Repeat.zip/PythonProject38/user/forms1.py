from django import forms
from django.core import validators
from .models import Account

class Signin(forms.ModelForm):
    class Meta:
        model= Account
        fields=['name','email','contact','username','password']
        labels={'name':'Enter Name','email':'Enter Email','contact':'Enter Contact','username':'Enter Username'}
        widgets = {'password': forms.PasswordInput(),}



