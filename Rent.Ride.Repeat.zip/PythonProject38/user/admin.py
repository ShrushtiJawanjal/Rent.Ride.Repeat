from django.contrib import admin
from .models import Account
from .models import Book
from .models import Complain

admin.site.register(Account)
admin.site.register(Book)
admin.site.register(Complain)
# Register your models here.
