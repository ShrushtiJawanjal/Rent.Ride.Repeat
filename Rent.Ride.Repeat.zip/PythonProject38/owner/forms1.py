from django import forms
from django.core import validators
from .models import CarInfo
class Vehicle_Details(forms.ModelForm):
    class Meta:
        model=CarInfo
        fields=['name','contact','vehicle_name','vehicle_model','fuel_type','vehicle_no']
        labels={'name':'Enter Name','contact':'Enter Contact','vehicle_name':'Vehicle_Name','vehicle_model':'Vehicle_Model','fuel_type':'Fuel_Type','vehicle_no':'Vehicle_No'}


