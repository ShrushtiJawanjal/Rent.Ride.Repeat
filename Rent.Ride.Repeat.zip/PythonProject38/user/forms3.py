from django.core import validators
from django import forms
from .models import Book

class Booking(forms.ModelForm):
    class Meta:
        model=Book
        fields=['name','email','contact','source_station','destination_station','date','pickup_date','return_date','no_of_passenger']
        labels={'name':'Enter Name','email':'Enter Email','contact':'Enter Contact','source_station':'Enter Source_Station','destination_station':'Enter Destination_Station','date':'Booking Date(YYYY-MM-DD)','pickup_date':'Enter Pickup_Date(YYYY-MM-DD)','return_date':'Return_Date(YYYY-MM-DD)','no_of_passenger':'No_Of_Passenger'}