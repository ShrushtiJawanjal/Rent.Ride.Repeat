from tempfile import template
from django.conf import settings
from django.shortcuts import render,redirect
from django.http import HttpResponse
from django.template import loader
from django.template.context_processors import request

from .forms1 import Signin
from .models import Account
from django.contrib.auth import authenticate, login as auth_login
from .forms2 import LoginForm
from .forms3 import Booking
from .models import Book
from .forms4 import Feedback
from .models import Complain
from ridesystem import settings
from django.core.mail import send_mail





def home(request):
    template=loader.get_template('home.html')
    return HttpResponse(template.render())

def gallery(request):
    template=loader.get_template('gallery.html')
    return HttpResponse(template.render())

def signup(request):
    if request.method=="POST":
        fm= Signin(request.POST)
        if fm.is_valid():
            fm.save()
            return render(request,'home.html')
            nm=fm.cleaned_data['name']
            em=fm.cleaned_data['email']
            cn=fm.cleaned_data['contact']
            un=fm.cleaned_data['username']
            pw=fm.cleaned_data['password']
            print(nm)
            print(em)
            print(cn)
            print(un)
            print(pw)
            reg = Signin(name=nm, email=em, contact=cn, username=un, password=pw)
            reg.save()
            return redirect('gallery')
    else:
            fm= Signin()
    return render(request,'signup.html',{'forms1':fm})

def login(request):
    if request.method=='POST':
        form=LoginForm(request.POST)
        if form.is_valid():
            username=form.cleaned_data['username']
            password=form.cleaned_data['password']
            user=authenticate(username=username,password=password)
            if user is not None:
                auth_login(request, user)
            return redirect('home')
    else:

            form=LoginForm()
    return render(request,'login.html',{'forms2':form})

def books(request):
    if request.method == 'POST':
        fm = Booking(request.POST)
        if fm.is_valid():
            data = fm.cleaned_data


            b = Book.objects.create(
                name=data['name'],
                email=data['email'],
                contact=data['contact'],
                source_station=data['source_station'],
                destination_station=data['destination_station'],
                date=data['date'],
                pickup_date=data['pickup_date'],
                return_date=data['return_date'],
                no_of_passenger=data['no_of_passenger'],
                status="Pending"
            )
            return redirect('status', id=b.id)
    else:
        fm = Booking()

    return render(request, 'booking.html', {'forms3': fm})

def complaints(request):
    if request.method=='POST':
        fm= Feedback (request.POST)
        if fm.is_valid():
            nm=fm.cleaned_data['name']
            em=fm.cleaned_data['email']
            cn=fm.cleaned_data['contact']
            msg=fm.cleaned_data['message']
            print(nm)
            print(em)
            print(cn)
            print(msg)
            reg=Complain(name=nm,email=em,contact=cn,message=msg)
            reg.save()
            subject="New Complaint Registered"
            to_email='shrushtijawanjal21@gmail.com'
            msg_body=f"Hello {nm},\n\ncomplaint:{msg}\nContact:{cn}\nEmail:{em}"
            send_mail(subject,msg_body,settings.EMAIL_HOST_USER,[to_email],fail_silently=False)
            return render(request,'home.html',{'name':nm})
    else:
        fm=Feedback()
    return render(request,'complaint.html',{'forms4':fm})

def status(request,id):
    b=Book.objects.get(id=id)
    return render(request,'status.html',{'b':b})


















