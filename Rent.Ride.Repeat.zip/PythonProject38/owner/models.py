from django.db import models
class CarInfo(models.Model):
    name=models.CharField(max_length=100)
    contact=models.CharField(max_length=100)
    vehicle_name=models.CharField(max_length=100)
    vehicle_model=models.CharField(max_length=100)
    fuel_type=models.CharField(max_length=100)
    vehicle_no=models.IntegerField()
    status=models.CharField(max_length=20,default='Pending')

# Create your models here.
