from django.shortcuts import render
from .forms1 import Vehicle_Details
from .models import CarInfo

def car_inform(request):
    if request.method=='POST':
        fm=Vehicle_Details(request.POST)
        if fm.is_valid():
            nm= fm.cleaned_data['name']
            c=fm.cleaned_data['contact']
            vn=fm.cleaned_data['vehicle_name']
            vm=fm.cleaned_data['vehicle_model']
            ft=fm.cleaned_data['fuel_type']
            vno=fm.cleaned_data['vehicle_no']
            print(nm)
            print(c)
            print(vn)
            print(vm)
            print(ft)
            print(vno)
            reg=CarInfo(name=nm,contact=c,vehicle_name=vn,vehicle_model=vm,fuel_type=ft,vehicle_no=vno)
            reg.save()
    else:
        fm=Vehicle_Details()
    return render(request,'car_details.html',{'forms1':fm})








# Create your views here.
