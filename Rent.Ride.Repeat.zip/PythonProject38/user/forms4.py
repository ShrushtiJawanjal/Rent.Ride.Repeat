from django import forms
from django.core import validators
from .models import Complain

class Feedback(forms.ModelForm):
    class Meta:
        model= Complain
        fields = ['name','email','contact','message']
        labels={'name':'Enter Name','email':'Enter Email','contact':'Enter Contact','message':'Enter Message'}
