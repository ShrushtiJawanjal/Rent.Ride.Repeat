from django.db import models

class Account(models.Model):
    name=models.CharField(max_length=100)
    email=models.EmailField(max_length=100)
    contact=models.IntegerField()
    username=models.CharField(max_length=100)
    password=models.CharField(max_length=100)

class Book(models.Model):
    name=models.CharField(max_length=100)
    email=models.CharField(max_length=100)
    contact = models.BigIntegerField()
    source_station=models.CharField(max_length=200)
    destination_station=models.CharField(max_length=200)
    date=models.DateField()
    pickup_date=models.DateField()
    return_date=models.DateField()
    no_of_passenger=models.IntegerField()
    status = models.CharField(max_length=20, default="Pending")

class Complain(models.Model):
    name=models.CharField(max_length=100)
    email=models.EmailField(max_length=100)
    contact=models.IntegerField()
    message=models.CharField(max_length=1000)




# Create your models here.
