from django.urls import path
from .import views

urlpatterns=[
    path('car_inform',views.car_inform,name='car_inform'),
    ]