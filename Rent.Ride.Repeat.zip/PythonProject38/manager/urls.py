from django.urls import path
from .import views

urlpatterns = [
    path('manager_logs', views.manager_logs, name='manager_logs'),
    path('manager_regs', views.manager_regs, name='manager_regs'),
    path('manager_dets', views.manager_dets, name='manager_dets'),
    path('manager/approve/<int:id>/', views.approve, name='approve'),
    path('manager/unapprove/<int:id>/', views.unapprove, name='unapprove'),
]