from tempfile import template

from django.shortcuts import render, redirect
from django.http import HttpResponse
from django.template import loader
from user.models import  Complain
from user.models import Book
from owner.models import CarInfo

# Create your views here.

def manager_logs(request):
        logs_data = Complain.objects.all().values()
        context = {
            'logs_data': logs_data
        }
        return render(request, 'manager_login.html', context)

def manager_regs(request):
    reg_data= Book.objects.all().values()
    context={
        'reg_data':reg_data
    }
    return render(request,'manager_booking.html',context)

def manager_dets(request):
    vehicle_data=CarInfo.objects.all().values()
    context={
        'vehicle_data':vehicle_data
    }
    return render(request,'manager_car_details.html',context)

def approve(request,id):
    b=Book.objects.get(id=id)
    b.status="Approved"
    b.save()
    return redirect('manager_regs')

def unapprove(request,id):
    b=Book.objects.get(id=id)
    b.status="Unapproved"
    b.save()
    return redirect('manager_regs')




